# The-Odin-Project-Calculator


## Summary

### What I learned
1. <button> the spaces between the HTML button element matters </button>
I was stuck trying to figure out why the buttons didn't register with the JavaScript functions. 

Issue: 
HTML: button> + <button
JS: operator == '+'

Solution:
HTML: button>+<button
JS: operator == '+'





